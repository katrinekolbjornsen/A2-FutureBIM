# Hi :) if just starting out - probably should start with the duplex.py this main.py references models that aren't shared on this repo

import HTMLBuild as hb

hb.modelLoader("22_03_01")